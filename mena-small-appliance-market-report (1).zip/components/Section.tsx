import React from 'react';
import { SectionContent, Language, Region, Product } from '../types';
import { ExternalLink, Tag } from 'lucide-react';

interface SectionProps {
  data: SectionContent;
  language: Language;
  region: Region;
}

const Section: React.FC<SectionProps> = ({ data, language, region }) => {
  const themeColor = region === 'jordan' ? 'text-emerald-700' : 'text-amber-700';
  const borderColor = region === 'jordan' ? 'border-emerald-500' : 'border-amber-500';
  const tagBg = region === 'jordan' ? 'bg-emerald-50' : 'bg-amber-50';
  const tagText = region === 'jordan' ? 'text-emerald-700' : 'text-amber-700';

  // Helper to parse text with Markdown-style links [text](url) or raw URLs
  const renderTextWithLinks = (text: string) => {
    // Regex for [label](url)
    const markdownLinkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
    // Regex for raw URLs (http/https)
    const urlRegex = /(https?:\/\/[^\s]+)/g;

    const parts = [];
    let lastIndex = 0;
    let match;

    // We prioritize markdown links first. 
    // Note: This is a simple parser and doesn't handle nested or complex cases perfectly, but sufficient for this report.
    
    // Simplification: We will just split by markdown link first.
    if (text.match(markdownLinkRegex)) {
        let localLastIndex = 0;
        while ((match = markdownLinkRegex.exec(text)) !== null) {
            if (match.index > localLastIndex) {
                parts.push(text.substring(localLastIndex, match.index));
            }
            parts.push(
                <a 
                    key={match.index} 
                    href={match[2]} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-blue-600 hover:underline break-all"
                >
                    {match[1]} <ExternalLink size={10} className="inline mb-1" />
                </a>
            );
            localLastIndex = markdownLinkRegex.lastIndex;
        }
        if (localLastIndex < text.length) {
            parts.push(text.substring(localLastIndex));
        }
        return parts;
    } 
    
    // If no markdown links, check for raw URLs
    if (text.match(urlRegex)) {
         let localLastIndex = 0;
        while ((match = urlRegex.exec(text)) !== null) {
            if (match.index > localLastIndex) {
                parts.push(text.substring(localLastIndex, match.index));
            }
            parts.push(
                <a 
                    key={match.index} 
                    href={match[0]} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-blue-600 hover:underline break-all"
                >
                    {match[0]}
                </a>
            );
            localLastIndex = urlRegex.lastIndex;
        }
        if (localLastIndex < text.length) {
            parts.push(text.substring(localLastIndex));
        }
        return parts;
    }

    return text;
  };

  const renderProductGrid = (products: Product[]) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {products.map((product, idx) => (
        <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex flex-col h-full">
            <h4 className="font-bold text-gray-900 mb-2">{product.name[language]}</h4>
            <div className="flex items-center gap-2 mb-3">
                <span className={`text-xs font-semibold px-2 py-1 rounded ${tagBg} ${tagText}`}>
                {product.price[language]}
                </span>
            </div>
            <ul className="text-sm text-gray-600 mb-4 space-y-1 flex-grow">
            {product.points.map((pt, pIdx) => (
                <li key={pIdx} className="flex items-start gap-2">
                <span className="mt-1.5 w-1 h-1 bg-gray-400 rounded-full flex-shrink-0" />
                <span>{renderTextWithLinks(pt[language])}</span>
                </li>
            ))}
            </ul>
            {product.link && (
            <div className="mt-auto pt-3 border-t border-gray-50">
                <a 
                    href={product.link.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className={`inline-flex items-center text-sm font-medium ${themeColor} hover:underline`}
                >
                    {product.link.label[language]} <ExternalLink size={12} className="ml-1" />
                </a>
            </div>
            )}
        </div>
        ))}
    </div>
  );

  return (
    <div className="mb-12 animate-fade-in scroll-mt-20" id={data.title.en.replace(/\s+/g, '-').toLowerCase()}>
      {/* Title */}
      <h2 className={`text-2xl font-bold mb-6 ${themeColor} border-l-4 ${borderColor} pl-4 flex items-center`}>
        {data.title[language]}
      </h2>

      {/* Main Content (Paragraphs) */}
      {data.content && (
        <div className="mb-6 text-gray-700 leading-relaxed space-y-4">
          {Array.isArray(data.content) ? (
            data.content.map((para, idx) => <div key={idx} className="text-base">{renderTextWithLinks(para[language])}</div>)
          ) : (
            <div className="text-base">{renderTextWithLinks(data.content[language])}</div>
          )}
        </div>
      )}

      {/* Top Level Products List (if any) */}
      {data.products && renderProductGrid(data.products)}

      {/* Recursive Subsections */}
      {data.subsections && (
        <div className="pl-0 md:pl-4 space-y-10 mt-8">
          {data.subsections.map((sub, idx) => (
            <div key={idx} className="border-l-2 border-gray-100 pl-4 md:pl-6">
              <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                <Tag size={18} className="text-gray-400" />
                {sub.title[language]}
              </h3>
               
               {/* Subsection Content */}
               {sub.content && (
                <div className="text-gray-600 leading-relaxed mb-6 space-y-3">
                  {Array.isArray(sub.content) ? (
                    sub.content.map((para, pIdx) => (
                        <div key={pIdx}>{renderTextWithLinks(para[language])}</div>
                    ))
                  ) : (
                    <div>{renderTextWithLinks(sub.content[language])}</div>
                  )}
                </div>
              )}

              {/* Subsection Products */}
              {sub.products && renderProductGrid(sub.products)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Section;