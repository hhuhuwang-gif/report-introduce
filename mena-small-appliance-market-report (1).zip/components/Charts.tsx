import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Language, Region } from '../types';

interface ChartsProps {
  region: Region;
  language: Language;
}

// Mock data based on the report values
const JORDAN_MARKET_DATA = [
  { name: '2021', value: 3.2 },
  { name: '2022', value: 3.5 },
  { name: '2023', value: 3.8 },
  { name: '2024', value: 4.1 },
  { name: '2025E', value: 4.4 },
];

const IRAQ_MARKET_DATA = [
  { name: '2021', value: 2.8 },
  { name: '2022', value: 3.1 },
  { name: '2023', value: 3.4 },
  { name: '2024', value: 3.81 },
  { name: '2025E', value: 4.23 },
];

const MATURITY_DATA_JORDAN = [
  { subject: 'Vacuum', A: 90, fullMark: 100 },
  { subject: 'Iron', A: 95, fullMark: 100 },
  { subject: 'Steamer', A: 60, fullMark: 100 },
  { subject: 'Coffee', A: 50, fullMark: 100 },
  { subject: 'Robot', A: 20, fullMark: 100 },
  { subject: 'Window', A: 10, fullMark: 100 },
];

const MATURITY_DATA_IRAQ = [
  { subject: 'Vacuum', A: 85, fullMark: 100 },
  { subject: 'Iron', A: 90, fullMark: 100 },
  { subject: 'Steamer', A: 40, fullMark: 100 },
  { subject: 'Coffee', A: 30, fullMark: 100 },
  { subject: 'Robot', A: 5, fullMark: 100 },
  { subject: 'Window', A: 2, fullMark: 100 },
];

const Charts: React.FC<ChartsProps> = ({ region, language }) => {
  const isJordan = region === 'jordan';
  const marketData = isJordan ? JORDAN_MARKET_DATA : IRAQ_MARKET_DATA;
  const maturityData = isJordan ? MATURITY_DATA_JORDAN : MATURITY_DATA_IRAQ;
  const color = isJordan ? '#10b981' : '#f59e0b'; // Emerald vs Amber

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
      {/* Market Size Chart */}
      <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
        <h3 className="text-lg font-bold text-gray-800 mb-4">
          {language === 'zh' ? '市场规模增长趋势 (估算)' : 'Market Size Growth Trend (Est.)'}
        </h3>
        <p className="text-xs text-gray-500 mb-4">
          {language === 'zh' ? '单位: 亿美元' : 'Unit: Billion USD'}
        </p>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={marketData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
              <Tooltip 
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                cursor={{ fill: '#f1f5f9' }}
              />
              <Bar dataKey="value" fill={color} radius={[4, 4, 0, 0]} barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Category Maturity Radar */}
      <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
        <h3 className="text-lg font-bold text-gray-800 mb-4">
          {language === 'zh' ? '品类市场成熟度' : 'Category Market Maturity'}
        </h3>
         <p className="text-xs text-gray-500 mb-4">
          {language === 'zh' ? '基于市场渗透率估算' : 'Based on estimated penetration'}
        </p>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={maturityData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12 }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
              <Radar
                name="Maturity"
                dataKey="A"
                stroke={color}
                fill={color}
                fillOpacity={0.6}
              />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Charts;