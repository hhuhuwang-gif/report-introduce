import React from 'react';
import { Globe, MapPin } from 'lucide-react';
import { Language, Region } from '../types';

interface TopBarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  region: Region;
  setRegion: (reg: Region) => void;
}

const TopBar: React.FC<TopBarProps> = ({ language, setLanguage, region, setRegion }) => {
  return (
    <div className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm backdrop-blur-md bg-opacity-90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${region === 'jordan' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
               <MapPin size={24} />
            </div>
            <h1 className="text-xl font-bold text-gray-900 hidden sm:block">
              {language === 'zh' ? '中东小家电市场报告' : 'MENA Small Appliance Report'}
            </h1>
            <h1 className="text-xl font-bold text-gray-900 sm:hidden">
              MENA Report
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {/* Region Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setRegion('jordan')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  region === 'jordan' 
                    ? 'bg-white text-emerald-700 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-900'
                }`}
              >
                {language === 'zh' ? '约旦' : 'Jordan'}
              </button>
              <button
                onClick={() => setRegion('iraq')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  region === 'iraq' 
                    ? 'bg-white text-amber-700 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-900'
                }`}
              >
                {language === 'zh' ? '伊拉克' : 'Iraq'}
              </button>
            </div>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'zh' ? 'en' : 'zh')}
              className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors border border-gray-200"
            >
              <Globe size={16} />
              <span>{language === 'zh' ? 'EN' : '中文'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;